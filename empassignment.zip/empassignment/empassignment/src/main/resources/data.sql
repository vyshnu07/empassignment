insert into employee(id, name, last_name) 
values(100,'sirisha','siri');
insert into employee (id, name, last_name) 
values(101,'neelima' ,'bandaru' );
insert into employee(id, name, last_name ) 
values(102,'surya', 'chandhra');



















